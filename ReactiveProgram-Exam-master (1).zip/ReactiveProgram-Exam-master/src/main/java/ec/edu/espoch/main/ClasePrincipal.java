
import ec.edu.espoch.vista.Interfaz;

public class ClasePrincipal {

    public static void main(String[] args) {
        Interfaz objInteraz = new Interfaz();
        objInteraz.setVisible(true);
       
        }
}


